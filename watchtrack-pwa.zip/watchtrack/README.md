# WatchTrack

A mobile-first React + TypeScript + Tailwind watchlist and progress tracker for movies, series and anime.

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. Production build: `npm run build`.

## APIs

- Anime: Jikan API v4 (`https://api.jikan.moe/v4`), no API key required.
- Movies & TV: TMDB API v3. Add a TMDB v3 API key from Settings. Without a key, the app uses local sample search results for a handful of popular titles and shows a connection prompt.

The TMDB key and watchlist are stored in this browser's localStorage. This is a client-side demo: do not use a sensitive/private API credential in a public deployment. For a production app, proxy TMDB requests through a backend and add authentication/cloud sync.

## Included

- Search, My List and Stats screens; title detail editor hides bottom navigation.
- Debounced search, status/type filters, sorting, quick add.
- Season-aware episode progress and automatic season rollover.
- Anime numeric episode input and ongoing episode handling.
- Completion modal and rating.
- Daily throttled update check on app load and manual sync.
- Jikan sequel lookup and TMDB season/episode-count change detection.
- Local persistence, JSON export/import, demo data reset.

## Notes / limitations

- The app stores Jikan's total episode count when supplied by the API; a null episode count is treated as ongoing.
- TMDB search/detail endpoints provide genres and season counts; mock search results are intentionally limited when no TMDB key is configured.
- Jikan's public API is rate-limited; the sync loop spaces anime detail/relation requests by 400 ms. For large lists, a server-side queue is recommended.
- TMDB's free developer API key is not a secret when used in a browser. Use a server-side proxy before publishing this app.

## Install on Android (PWA)

WatchTrack is also configured as an installable Progressive Web App (PWA).

1. Deploy the built `dist/` folder to an HTTPS host (for example, Netlify, Vercel, or your own HTTPS server). Service workers and PWA installation require HTTPS, except on `localhost` during development.
2. Open the deployed URL in Chrome on Android.
3. Tap **Install** when the WatchTrack install prompt appears, or open Chrome's ⋮ menu and choose **Install app** / **Add to Home screen**.
4. Launch WatchTrack from the new home-screen icon. It opens in standalone app mode without the browser address bar.

The service worker caches the app shell for repeat/offline launches. Your watchlist remains in localStorage on that device. Live search and API sync require an internet connection. On iPhone/iPad, use Safari's Share menu → **Add to Home Screen**.

Build the deployable PWA bundle with:

```bash
npm install
npm run build
```

Upload the contents of `dist/` to an HTTPS static host. A local `npm run dev` session is for development and does not register the production service worker.

## Deploy from an Android phone using GitHub Pages

This repository includes `.github/workflows/deploy.yml`. After the source files are committed to the `main` branch, GitHub Actions installs dependencies, builds the app and publishes `dist/` to GitHub Pages automatically.

### Phone-only route (using GitHub Codespaces)

1. In Chrome, open https://github.com/new and create a repository named `watchtrack-pwa`. Choose **Public** (GitHub Pages is simplest on a free public repository). Do not add a README, license or `.gitignore` because this ZIP already contains the project files.
2. In the new repository, choose **Add file → Upload files** and upload `watchtrack-pwa.zip` from your phone. Commit the ZIP to `main`.
3. Open the repository's green **Code** button → **Codespaces** → **Create codespace on main**. If GitHub asks you to enable Codespaces, follow its prompts; availability and free quota depend on your account.
4. In the Codespaces terminal, run:

   ```bash
   unzip watchtrack-pwa.zip
   cp -R watchtrack/. .
   rm -rf watchtrack watchtrack-pwa.zip
   git add -A
   git commit -m "Add WatchTrack PWA source"
   git push
   ```

5. In the repository, open **Actions** and wait for **Deploy WatchTrack PWA to GitHub Pages** to finish successfully.
6. Open **Settings → Pages**. The site URL will look like `https://YOUR-USERNAME.github.io/watchtrack-pwa/`.
7. Open that URL in Chrome on Android, then use Chrome's menu → **Install app** / **Add to Home screen**.

If Codespaces is unavailable on your account, the same ZIP can be extracted on Android and the files uploaded to the repository with GitHub's web uploader; preserve the folder structure (`src`, `public`, and `.github/workflows`).
