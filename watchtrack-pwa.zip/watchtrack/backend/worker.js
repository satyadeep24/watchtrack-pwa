export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = request.headers.get("Origin") || "";
    const allowed = (env.ALLOWED_ORIGINS || "").split(",").map(x => x.trim()).filter(Boolean);
    const originAllowed = !origin || allowed.includes(origin);
    const headers = {
      "Access-Control-Allow-Origin": originAllowed ? (origin || "*") : "null",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Cache-Control": "public, max-age=300",
      "Vary": "Origin"
    };
    if (request.method === "OPTIONS") return new Response(null, { headers });
    if (!originAllowed) return new Response("Origin not allowed", { status: 403 });
    if (request.method !== "GET") return new Response("Method not allowed", { status: 405 });
    if (!env.TMDB_API_KEY) return new Response("TMDB backend is not configured", { status: 503, headers });
    const path = url.pathname.replace(/^\\/api\\/tmdb/, "");
    if (!path || !/^\\/(trending|search|movie|tv)\\//.test(path)) return new Response("Not found", { status: 404, headers });
    const upstream = new URL("https://api.themoviedb.org/3" + path);
    for (const [key, value] of url.searchParams) upstream.searchParams.set(key, value);
    upstream.searchParams.set("api_key", env.TMDB_API_KEY);
    const response = await fetch(upstream.toString(), { headers: { Accept: "application/json" } });
    const body = await response.text();
    return new Response(body, { status: response.status, headers: { ...headers, "Content-Type": "application/json" } });
  }
};
