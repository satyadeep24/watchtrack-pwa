# WatchTrack TMDB proxy

Deploy this folder as a Cloudflare Worker. Add `TMDB_API_KEY` as a Worker secret (never commit the key). Set `ALLOWED_ORIGINS` to your exact GitHub Pages origin, e.g. `https://satyadeep24.github.io`. Then set GitHub Actions repository variable `VITE_TMDB_PROXY_URL` to the deployed Worker URL plus `/api/tmdb`, and update the workflow to pass that variable at build time. The app uses Jikan directly for anime and does not require a key.

The Worker currently forwards only GET requests under `/trending`, `/search`, `/movie`, and `/tv`. Add Cloudflare rate limiting before public production use.
