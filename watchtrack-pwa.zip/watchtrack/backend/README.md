# WatchTrack backend status

The current WatchTrack build uses public, no-key metadata APIs directly:
- Cinemeta for movie catalogue/search metadata.
- TVmaze for TV series, seasons and episode metadata.
- Jikan for anime.

The Cloudflare TMDB proxy in `worker.js` is retained only for possible future use with legacy builds. It is not required by the current frontend. Do not add a TMDB secret or configure `VITE_TMDB_PROXY_URL` for this build.

Before public/commercial release, review each provider's terms, attribution and caching requirements. TVmaze requires attribution and share-alike compliance. Cinemeta is a community catalogue service and availability is not guaranteed. Jikan is rate-limited; the app should cache results and avoid rapid repeated requests.
