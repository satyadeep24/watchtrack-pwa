import test from 'node:test';
import assert from 'node:assert/strict';
import { changeStatus, markTitleCompleted, progress, startTrackingUpdate, watchedCount } from '../src/domain.ts';

const base = (overrides = {}) => ({
  id: 'test-title', sourceId: 1, kind: 'Series', source: 'mock', title: 'Test Show', poster: '',
  genres: [], seasons: [
    { season_number: 1, episode_count: 8, name: 'Season 1' },
    { season_number: 2, episode_count: 10, name: 'Season 2' },
  ], totalEpisodes: 18, currentSeason: 1, currentEpisode: 6, watchStatus: 'Watching',
  userRating: 0, note: '', addedAt: 1, updatedAt: 1, ...overrides,
});

test('completing a series moves progress to the final episode of the final season', () => {
  const completed = markTitleCompleted(base());
  assert.equal(completed.watchStatus, 'Completed');
  assert.equal(completed.currentSeason, 2);
  assert.equal(completed.currentEpisode, 10);
  assert.equal(progress(completed), 100);
  assert.equal(watchedCount(completed), 18);
  assert.ok(completed.completedAt);
});

test('completing a known-length anime moves episode progress to its total', () => {
  const completed = markTitleCompleted(base({ kind: 'Anime', seasons: undefined, totalEpisodes: 24, currentEpisode: 9 }));
  assert.equal(completed.currentEpisode, 24);
  assert.equal(progress(completed), 100);
});

test('completed movies receive a completion timestamp without episode fields', () => {
  const completed = markTitleCompleted(base({ kind: 'Movie', seasons: undefined, totalEpisodes: null }));
  assert.equal(completed.watchStatus, 'Completed');
  assert.ok(completed.completedAt);
});

test('moving a completed title back to watching clears its completion date', () => {
  const completed = markTitleCompleted(base());
  const reopened = changeStatus(completed, 'Watching');
  assert.equal(reopened.watchStatus, 'Watching');
  assert.equal(reopened.completedAt, undefined);
});

test('starting a new season resets progress to that season', () => {
  const updated = startTrackingUpdate(base({ hasNewSeason: true, newSeasonNumber: 3,
    seasons: [...base().seasons, { season_number: 3, episode_count: 6, name: 'Season 3' }] }));
  assert.equal(updated.currentSeason, 3);
  assert.equal(updated.currentEpisode, 0);
  assert.equal(updated.hasNewSeason, false);
});

test('starting newly added episodes preserves existing episode progress', () => {
  const updated = startTrackingUpdate(base({ hasNewEpisodes: true, newEpisodesSeasonNumber: 2, currentSeason: 2, currentEpisode: 4 }));
  assert.equal(updated.currentSeason, 2);
  assert.equal(updated.currentEpisode, 4);
  assert.equal(updated.hasNewEpisodes, false);
});

test('new episodes in a different season do not inherit the old season episode count', () => {
  const updated = startTrackingUpdate(base({ hasNewEpisodes: true, newEpisodesSeasonNumber: 3, currentSeason: 2, currentEpisode: 7 }));
  assert.equal(updated.currentSeason, 3);
  assert.equal(updated.currentEpisode, 0);
});
