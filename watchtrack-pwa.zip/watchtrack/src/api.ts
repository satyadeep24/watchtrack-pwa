import type { SearchResult, Title, Season } from './types';

const JIKAN = 'https://api.jikan.moe/v4';
const TVMAZE = 'https://api.tvmaze.com';
const CINEMETA = 'https://v3-cinemeta.strem.io';

async function get<T>(url: string, timeoutMs = 12000): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { Accept: 'application/json' },
    });
    if (!response.ok) throw new Error(`API error ${response.status}`);
    return await response.json() as T;
  } finally {
    clearTimeout(timer);
  }
}

const yearFrom = (value?: string | null): number | null => {
  if (!value) return null;
  const match = String(value).match(/\d{4}/);
  return match ? Number(match[0]) : null;
};

function stableNumericId(value: string): number {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i++) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

const mapCinemeta = (meta: any): SearchResult => ({
  id: stableNumericId(String(meta.id)),
  sourceId: String(meta.id),
  kind: 'Movie',
  source: 'cinemeta',
  title: meta.name || 'Untitled movie',
  poster: meta.poster || '',
  year: yearFrom(meta.releaseInfo),
  rating: Number(meta.imdbRating) || null,
  genres: Array.isArray(meta.genres) ? meta.genres : [],
  overview: meta.description || '',
});

const mapTvmaze = (show: any): SearchResult => ({
  id: Number(show.id),
  sourceId: Number(show.id),
  kind: 'Series',
  source: 'tvmaze',
  title: show.name || 'Untitled series',
  poster: show.image?.original || show.image?.medium || '',
  year: yearFrom(show.premiered),
  rating: Number(show.rating?.average) || null,
  genres: Array.isArray(show.genres) ? show.genres : [],
  overview: show.summary?.replace(/<[^>]*>/g, '') || '',
});

const mapAnime = (a: any): SearchResult => ({
  id: Number(a.mal_id),
  sourceId: Number(a.mal_id),
  kind: 'Anime',
  source: 'jikan',
  title: a.title_english || a.title,
  poster: a.images?.jpg?.large_image_url || a.images?.jpg?.image_url || '',
  year: a.year || a.aired?.prop?.from?.year || null,
  rating: Number(a.score) || null,
  genres: a.genres?.map((g: any) => g.name) || [],
  overview: a.synopsis || '',
});

export interface DiscoveryData {
  movies: SearchResult[];
  series: SearchResult[];
  anime: SearchResult[];
}

export async function discoverMovies(): Promise<SearchResult[]> {
  const data = await get<any>(`${CINEMETA}/catalog/movie/top.json`);
  return (data.metas || []).map(mapCinemeta).slice(0, 18);
}

export async function discoverSeries(): Promise<SearchResult[]> {
  const data = await get<any[]>(`${TVMAZE}/shows?page=0`);
  return data
    .filter((show) => show && show.id && show.name)
    .sort((a, b) => (b.rating?.average || 0) - (a.rating?.average || 0))
    .slice(0, 18)
    .map(mapTvmaze);
}

export async function discoverAnime(): Promise<SearchResult[]> {
  const data = await get<any>(`${JIKAN}/top/anime?limit=18`);
  return (data.data || []).map(mapAnime);
}

export async function discoverTitles(): Promise<DiscoveryData> {
  const [movies, series, anime] = await Promise.allSettled([
    discoverMovies(),
    discoverSeries(),
    discoverAnime(),
  ]);
  const result: DiscoveryData = {
    movies: movies.status === 'fulfilled' ? movies.value : [],
    series: series.status === 'fulfilled' ? series.value : [],
    anime: anime.status === 'fulfilled' ? anime.value : [],
  };
  if (!result.movies.length && !result.series.length && !result.anime.length) {
    throw new Error('All discovery providers are unavailable');
  }
  return result;
}

export async function searchTitles(query: string, kind: string, _key = ''): Promise<SearchResult[]> {
  const q = query.trim();
  if (!q) return [];
  const jobs: Promise<SearchResult[]>[] = [];

  if (kind === 'All' || kind === 'Movies') {
    jobs.push(get<any>(`${CINEMETA}/catalog/movie/top/search/${encodeURIComponent(q)}.json`)
      .then((data) => (data.metas || []).map(mapCinemeta)));
  }
  if (kind === 'All' || kind === 'Series') {
    jobs.push(get<any[]>(`${TVMAZE}/search/shows?q=${encodeURIComponent(q)}`)
      .then((data) => data.map((entry) => mapTvmaze(entry.show))));
  }
  if (kind === 'All' || kind === 'Anime') {
    jobs.push(get<any>(`${JIKAN}/anime?q=${encodeURIComponent(q)}&limit=12`)
      .then((data) => (data.data || []).map(mapAnime)));
  }

  const settled = await Promise.allSettled(jobs);
  const successful = settled.filter(
    (entry): entry is PromiseFulfilledResult<SearchResult[]> => entry.status === 'fulfilled',
  );
  if (!successful.length) throw new Error('Search providers unavailable');
  return successful.flatMap((entry) => entry.value).slice(0, 36);
}

export async function hydrate(result: SearchResult, _key = ''): Promise<Partial<Title>> {
  if (result.source === 'jikan') {
    const response = await get<any>(`${JIKAN}/anime/${result.sourceId}/full`);
    const anime = response.data;
    return {
      sourceId: result.sourceId,
      source: 'jikan',
      totalEpisodes: anime.episodes ?? null,
      statusText: anime.status,
      duration: anime.duration,
      genres: anime.genres?.map((genre: any) => genre.name) || result.genres,
      rating: anime.score,
      year: anime.year || result.year,
      poster: anime.images?.jpg?.large_image_url || result.poster,
    };
  }

  if (result.source === 'tvmaze') {
    const [show, seasons] = await Promise.all([
      get<any>(`${TVMAZE}/shows/${result.sourceId}`),
      get<any[]>(`${TVMAZE}/shows/${result.sourceId}/seasons`),
    ]);
    const mapped: Season[] = seasons
      .filter((season) => Number(season.number) > 0)
      .map((season) => ({
        season_number: Number(season.number),
        episode_count: Number(season.episodeOrder) || 0,
        name: season.name || `Season ${season.number}`,
        air_date: season.premiereDate || null,
      }));
    return {
      sourceId: result.sourceId,
      source: 'tvmaze',
      seasons: mapped,
      totalEpisodes: mapped.reduce((sum, season) => sum + season.episode_count, 0) || null,
      statusText: show.status,
      genres: show.genres || result.genres,
      poster: show.image?.original || show.image?.medium || result.poster,
      duration: show.averageRuntime || show.runtime || null,
      year: yearFrom(show.premiered) || result.year,
    };
  }

  return {
    sourceId: result.sourceId,
    source: 'cinemeta',
    totalEpisodes: null,
    genres: result.genres,
    year: result.year,
    rating: result.rating,
    poster: result.poster,
    statusText: 'Movie',
  };
}

export async function syncTitle(title: Title, _key = ''): Promise<Partial<Title>> {
  if (title.source === 'tvmaze' && title.kind === 'Series') {
    const [show, seasons] = await Promise.all([
      get<any>(`${TVMAZE}/shows/${title.sourceId}`),
      get<any[]>(`${TVMAZE}/shows/${title.sourceId}/seasons`),
    ]);
    const mapped: Season[] = seasons
      .filter((season) => Number(season.number) > 0)
      .map((season) => ({
        season_number: Number(season.number),
        episode_count: Number(season.episodeOrder) || 0,
        name: season.name || `Season ${season.number}`,
        air_date: season.premiereDate || null,
      }));
    const old = title.seasons || [];
    const added = mapped.find((season) => !old.some((item) => item.season_number === season.season_number));
    const expanded = mapped.find((season) =>
      old.some((item) => item.season_number === season.season_number) &&
      season.episode_count > (old.find((item) => item.season_number === season.season_number)?.episode_count || 0),
    );
    return {
      seasons: mapped,
      totalEpisodes: mapped.reduce((sum, season) => sum + season.episode_count, 0) || title.totalEpisodes,
      statusText: show.status,
      hasNewSeason: !!added || !!title.hasNewSeason,
      newSeasonNumber: added?.season_number ?? title.newSeasonNumber,
      newSeasonLabel: added ? `${added.name} Available` : expanded ? `${expanded.name} Updated` : title.newSeasonLabel,
      hasNewEpisodes: !!expanded || !!title.hasNewEpisodes,
      newEpisodesSeasonNumber: expanded?.season_number ?? title.newEpisodesSeasonNumber,
    };
  }

  if (title.source === 'jikan') {
    const data = await get<any>(`${JIKAN}/anime/${title.sourceId}`);
    await new Promise((resolve) => setTimeout(resolve, 400));
    const relations = await get<any>(`${JIKAN}/anime/${title.sourceId}/relations`);
    const anime = data.data;
    const sequel = relations.data?.flatMap((relation: any) =>
      relation.entry?.map((entry: any) => ({ ...entry, relation: relation.relation })) || [],
    ).find((entry: any) => entry.relation === 'Sequel' && entry.type === 'anime');
    const episodes = anime.episodes ?? null;
    return {
      totalEpisodes: episodes,
      statusText: anime.status,
      hasNewEpisodes: (episodes !== null && episodes > (title.totalEpisodes ?? 0)) || !!title.hasNewEpisodes,
      sequelAvailable: sequel && !title.sequelAvailable
        ? { mal_id: sequel.mal_id, title: sequel.name }
        : title.sequelAvailable,
    };
  }
  return {};
}
