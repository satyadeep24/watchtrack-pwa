import type {SearchResult,Title,Season} from './types';
const J='https://api.jikan.moe/v4', IMG='https://image.tmdb.org/t/p/w500';
const proxy=(import.meta as any).env?.VITE_TMDB_PROXY_URL?.replace(/\/$/,'') || '/api/tmdb';
async function get<T>(url:string):Promise<T>{const r=await fetch(url);if(!r.ok)throw new Error(`API error ${r.status}`);return r.json()}
async function tmdb(path:string){return get<any>(`${proxy}${path.startsWith('/')?path:`/${path}`}`)}
const mapMovie=(a:any):SearchResult=>({id:a.id,kind:'Movie',source:'tmdb',title:a.title||a.name,poster:a.poster_path?IMG+a.poster_path:'',year:a.release_date?+a.release_date.slice(0,4):null,rating:a.vote_average,genres:[]});
const mapTv=(a:any):SearchResult=>({id:a.id,kind:'Series',source:'tmdb',title:a.name||a.title,poster:a.poster_path?IMG+a.poster_path:'',year:a.first_air_date?+a.first_air_date.slice(0,4):null,rating:a.vote_average,genres:[]});
const mapAnime=(a:any):SearchResult=>({id:a.mal_id,kind:'Anime',source:'jikan',title:a.title_english||a.title,poster:a.images?.jpg?.large_image_url||a.images?.jpg?.image_url||'',year:a.year||a.aired?.prop?.from?.year,rating:a.score,genres:a.genres?.map((g:any)=>g.name)||[]});
export interface DiscoveryData {movies:SearchResult[];series:SearchResult[];anime:SearchResult[]}
export async function discoverTitles():Promise<DiscoveryData>{
 const tasks=await Promise.allSettled([
  tmdb('/trending/movie/week').then(d=>(d.results||[]).map(mapMovie)),
  tmdb('/trending/tv/week').then(d=>(d.results||[]).map(mapTv)),
  get<any>(`${J}/top/anime?limit=12`).then(d=>(d.data||[]).map(mapAnime))
 ]);
 const value=(i:number)=>{const task=tasks[i];return task.status==='fulfilled'?task.value:[];};
 const data={movies:value(0),series:value(1),anime:value(2)};
 if(!data.movies.length&&!data.series.length&&!data.anime.length)throw new Error('Discovery services unavailable');
 return data;
}
export async function searchTitles(q:string,kind:string,_key=''):Promise<SearchResult[]>{
 if(!q.trim())return[];
 const jobs:Promise<SearchResult[]>[]=[];
 if(kind==='All'||kind==='Anime')jobs.push(get<any>(`${J}/anime?q=${encodeURIComponent(q)}&limit=12`).then(d=>(d.data||[]).map(mapAnime)));
 if(kind==='All'||kind==='Movies')jobs.push(tmdb(`/search/movie?query=${encodeURIComponent(q)}`).then(d=>(d.results||[]).map(mapMovie)));
 if(kind==='All'||kind==='Series')jobs.push(tmdb(`/search/tv?query=${encodeURIComponent(q)}`).then(d=>(d.results||[]).map(mapTv)));
 const settled=await Promise.allSettled(jobs);const successful=settled.filter((x):x is PromiseFulfilledResult<SearchResult[]>=>x.status==='fulfilled');
 if(!successful.length)throw new Error('Search providers unavailable');
 return successful.flatMap(x=>x.value).slice(0,36);
}
export async function hydrate(r:SearchResult,_key=''):Promise<Partial<Title>>{
 if(r.source==='jikan'){const d=await get<any>(`${J}/anime/${r.id}/full`);const a=d.data;return{sourceId:r.id,source:'jikan',totalEpisodes:a.episodes??null,statusText:a.status,duration:a.duration,genres:a.genres?.map((g:any)=>g.name)||r.genres,rating:a.score,year:a.year||r.year,poster:a.images?.jpg?.large_image_url||r.poster};}
 if(r.kind==='Series'){const d=await tmdb(`/tv/${r.id}`);const seasons:Season[]=(d.seasons||[]).filter((s:any)=>s.season_number>0).map((s:any)=>({season_number:s.season_number,episode_count:s.episode_count,name:s.name,air_date:s.air_date}));return{sourceId:r.id,source:'tmdb',seasons,totalEpisodes:seasons.reduce((n,s)=>n+s.episode_count,0),statusText:d.status,genres:d.genres?.map((g:any)=>g.name)||r.genres,poster:d.poster_path?IMG+d.poster_path:r.poster};}
 const d=await tmdb(`/movie/${r.id}`);return{sourceId:r.id,source:'tmdb',duration:d.runtime,genres:d.genres?.map((g:any)=>g.name)||r.genres,poster:d.poster_path?IMG+d.poster_path:r.poster};
}
export async function syncTitle(t:Title,_key=''):Promise<Partial<Title>>{
 if(t.source==='tmdb'&&t.kind==='Series'){const d=await tmdb(`/tv/${t.sourceId}`);const seasons:Season[]=(d.seasons||[]).filter((s:any)=>s.season_number>0).map((s:any)=>({season_number:s.season_number,episode_count:s.episode_count,name:s.name,air_date:s.air_date}));const old=t.seasons||[];const newSeason=seasons.find(s=>!old.some(o=>o.season_number===s.season_number));const expanded=seasons.find(s=>old.some(o=>o.season_number===s.season_number)&&s.episode_count>(old.find(o=>o.season_number===s.season_number)?.episode_count||0));return{seasons,totalEpisodes:seasons.reduce((n,s)=>n+s.episode_count,0),hasNewSeason:!!newSeason||!!t.hasNewSeason,newSeasonNumber:newSeason?.season_number??t.newSeasonNumber,newSeasonLabel:newSeason?`${newSeason.name} Available`:expanded?`${expanded.name} Updated`:t.newSeasonLabel,hasNewEpisodes:!!expanded||!!t.hasNewEpisodes,newEpisodesSeasonNumber:expanded?.season_number??t.newEpisodesSeasonNumber};}
 if(t.source==='jikan'){const d=await get<any>(`${J}/anime/${t.sourceId}`);await new Promise(r=>setTimeout(r,400));const rel=await get<any>(`${J}/anime/${t.sourceId}/relations`);const a=d.data;const sequel=rel.data?.flatMap((x:any)=>x.entry?.map((e:any)=>({...e,relation:x.relation}))||[]).find((x:any)=>x.relation==='Sequel'&&x.type==='anime');const eps=a.episodes??null;return{totalEpisodes:eps,statusText:a.status,hasNewEpisodes:(eps!==null&&eps>(t.totalEpisodes??0))||!!t.hasNewEpisodes,sequelAvailable:sequel&&!t.sequelAvailable?{mal_id:sequel.mal_id,title:sequel.name}:t.sequelAvailable};}
 return{};
}
