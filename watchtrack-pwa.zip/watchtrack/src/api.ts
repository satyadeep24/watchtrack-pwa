import type { SearchResult, Title, Season } from './types';

const TVMAZE = 'https://api.tvmaze.com';
const CINEMETA = 'https://v3-cinemeta.strem.io';

async function get<T>(url: string, timeoutMs = 12000, retries = 2): Promise<T> {
  for (let attempt = 0; ; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, {
        signal: controller.signal,
        headers: { Accept: 'application/json' },
      });
      if (response.ok) return await response.json() as T;
      // Jikan and TVmaze rate-limit (429) and occasionally 5xx: retry with backoff.
      if ((response.status === 429 || response.status >= 500) && attempt < retries) {
        await new Promise((resolve) => setTimeout(resolve, 1200 * (attempt + 1)));
        continue;
      }
      throw new Error(`API error ${response.status}`);
    } catch (error) {
      if (attempt < retries && (error as Error)?.name !== 'Error') {
        await new Promise((resolve) => setTimeout(resolve, 1200 * (attempt + 1)));
        continue;
      }
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }
}

const yearFrom = (value?: string | null): number | null => {
  if (!value) return null;
  const match = String(value).match(/\d{4}/);
  return match ? Number(match[0]) : null;
};

function stableNumericId(value: string): number {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i++) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

const mapCinemeta = (meta: any): SearchResult => ({
  id: stableNumericId(String(meta.id)),
  sourceId: String(meta.id),
  kind: 'Movie',
  source: 'cinemeta',
  title: meta.name || 'Untitled movie',
  poster: meta.poster || '',
  year: yearFrom(meta.releaseInfo),
  rating: Number(meta.imdbRating) || null,
  genres: Array.isArray(meta.genres) ? meta.genres : [],
  overview: meta.description || '',
});

const cleanSummary = (value?: string | null) =>
  (value || '').replace(/<[^>]*>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;|&rsquo;/g, "'").replace(/&nbsp;/g, ' ').trim();

const mapTvmaze = (show: any): SearchResult => ({
  id: Number(show.id),
  sourceId: Number(show.id),
  kind: 'Series',
  source: 'tvmaze',
  title: show.name || 'Untitled series',
  poster: show.image?.original || show.image?.medium || '',
  year: yearFrom(show.premiered),
  rating: Number(show.rating?.average) || null,
  genres: Array.isArray(show.genres) ? show.genres : [],
  overview: cleanSummary(show.summary),
});

// TVmaze leaves `episodeOrder` null for seasons that are still airing. Fall back
// to counting the episodes that exist so progress and update detection stay correct.
async function mapTvmazeSeasons(showId: number | string | undefined, seasons: any[]): Promise<Season[]> {
  const real = seasons.filter((season) => Number(season.number) > 0);
  let counts: Record<number, number> | null = null;
  if (real.some((season) => !Number(season.episodeOrder))) {
    try {
      const episodes = await get<any[]>(`${TVMAZE}/shows/${showId}/episodes`);
      counts = {};
      for (const episode of episodes) {
        const n = Number(episode.season);
        counts[n] = (counts[n] || 0) + 1;
      }
    } catch { counts = null; }
  }
  return real.map((season) => ({
    season_number: Number(season.number),
    episode_count: Number(season.episodeOrder) || counts?.[Number(season.number)] || 0,
    name: season.name || `Season ${season.number}`,
    air_date: season.premiereDate || null,
  }));
}

export interface DiscoveryData {
  movies: SearchResult[];
  series: SearchResult[];
  anime: SearchResult[];
}

export async function discoverMovies(): Promise<SearchResult[]> {
  const data = await get<any>(`${CINEMETA}/catalog/movie/top.json`);
  return (data.metas || []).map(mapCinemeta).slice(0, 18);
}

export async function discoverSeries(): Promise<SearchResult[]> {
  // Currently airing streaming shows; fall back to the generic catalogue if unavailable.
  let shows: any[] = [];
  try {
    const schedule = await get<any[]>(`${TVMAZE}/schedule/web`);
    const seen = new Set<number>();
    for (const entry of schedule) {
      const show = entry?._embedded?.show;
      if (show?.id && !seen.has(show.id)) { seen.add(show.id); shows.push(show); }
    }
  } catch { shows = []; }
  if (!shows.length) shows = await get<any[]>(`${TVMAZE}/shows?page=0`);
  return shows
    .filter((show) => show && show.id && show.name && show.image)
    .sort((a, b) => (b.rating?.average || 0) - (a.rating?.average || 0))
    .slice(0, 18)
    .map(mapTvmaze);
}

// ---- Anime via AniList (free, no key, CORS enabled). Titles keep MyAnimeList ids
// (source "jikan") so libraries saved by earlier versions keep working.
const ANILIST = 'https://graphql.anilist.co';

async function anilist<T>(query: string, variables: Record<string, unknown> = {}, retries = 2): Promise<T> {
  for (let attempt = 0; ; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    try {
      const response = await fetch(ANILIST, {
        method: 'POST',
        signal: controller.signal,
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ query, variables }),
      });
      if (response.ok) {
        const json = await response.json();
        if (json.errors?.length && !json.data) throw new Error(json.errors[0]?.message || 'AniList error');
        return json.data as T;
      }
      if ((response.status === 429 || response.status >= 500) && attempt < retries) {
        await new Promise((resolve) => setTimeout(resolve, 1500 * (attempt + 1)));
        continue;
      }
      throw new Error(`AniList error ${response.status}`);
    } catch (error) {
      if (attempt < retries && (error as Error)?.name !== 'Error') {
        await new Promise((resolve) => setTimeout(resolve, 1500 * (attempt + 1)));
        continue;
      }
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }
}

const MEDIA_FIELDS = `idMal title { english romaji } coverImage { extraLarge large } seasonYear startDate { year }
  averageScore genres description(asHtml: false) episodes duration status format`;

const stripHtml = (value?: string | null) =>
  (value || '').replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]*>/g, '').trim();

const prettyStatus = (value?: string | null) =>
  ({ FINISHED: 'Finished airing', RELEASING: 'Currently airing', NOT_YET_RELEASED: 'Not yet aired', CANCELLED: 'Cancelled', HIATUS: 'On hiatus' } as Record<string, string>)[value || ''] || value || undefined;

const mapAniList = (m: any): SearchResult => ({
  id: Number(m.idMal),
  sourceId: Number(m.idMal),
  kind: 'Anime',
  source: 'jikan',
  title: m.title?.english || m.title?.romaji || 'Untitled anime',
  poster: m.coverImage?.extraLarge || m.coverImage?.large || '',
  year: m.seasonYear || m.startDate?.year || null,
  rating: m.averageScore ? Math.round(m.averageScore) / 10 : null,
  genres: Array.isArray(m.genres) ? m.genres : [],
  overview: stripHtml(m.description),
  totalEpisodes: m.episodes ?? null,
  duration: m.duration ?? null,
  statusText: prettyStatus(m.status),
});

export async function discoverAnime(): Promise<SearchResult[]> {
  const data = await anilist<any>(`query { Page(perPage: 30) { media(type: ANIME, sort: SCORE_DESC, popularity_greater: 60000, isAdult: false) { ${MEDIA_FIELDS} } } }`);
  return (data.Page?.media || []).filter((m: any) => m.idMal).slice(0, 18).map(mapAniList);
}

async function searchAnime(q: string): Promise<SearchResult[]> {
  const data = await anilist<any>(
    `query ($q: String) { Page(perPage: 15) { media(search: $q, type: ANIME, isAdult: false, sort: SEARCH_MATCH) { ${MEDIA_FIELDS} } } }`,
    { q },
  );
  return (data.Page?.media || []).filter((m: any) => m.idMal).map(mapAniList);
}

export async function discoverTitles(): Promise<DiscoveryData> {
  const [movies, series, anime] = await Promise.allSettled([
    discoverMovies(),
    discoverSeries(),
    discoverAnime(),
  ]);
  const result: DiscoveryData = {
    movies: movies.status === 'fulfilled' ? movies.value : [],
    series: series.status === 'fulfilled' ? series.value : [],
    anime: anime.status === 'fulfilled' ? anime.value : [],
  };
  if (!result.movies.length && !result.series.length && !result.anime.length) {
    throw new Error('All discovery providers are unavailable');
  }
  return result;
}

export async function searchTitles(query: string, kind: string, _key = ''): Promise<SearchResult[]> {
  const q = query.trim();
  if (!q) return [];
  const jobs: Promise<SearchResult[]>[] = [];

  if (kind === 'All' || kind === 'Movies') {
    jobs.push(get<any>(`${CINEMETA}/catalog/movie/top/search=${encodeURIComponent(q)}.json`)
      .then((data) => (data.metas || []).map(mapCinemeta)));
  }
  if (kind === 'All' || kind === 'Series') {
    jobs.push(get<any[]>(`${TVMAZE}/search/shows?q=${encodeURIComponent(q)}`)
      .then((data) => data.map((entry) => mapTvmaze(entry.show))));
  }
  if (kind === 'All' || kind === 'Anime') {
    jobs.push(searchAnime(q));
  }

  const settled = await Promise.allSettled(jobs);
  const successful = settled.filter(
    (entry): entry is PromiseFulfilledResult<SearchResult[]> => entry.status === 'fulfilled',
  );
  if (!successful.length) throw new Error('Search providers unavailable');
  return successful.flatMap((entry) => entry.value).slice(0, 36);
}

const ANIME_DETAIL = `${MEDIA_FIELDS}
  relations { edges { relationType node { idMal type title { english romaji } } } }`;

async function animeDetail(malId: number | string): Promise<any> {
  const data = await anilist<any>(
    `query ($id: Int) { Media(idMal: $id, type: ANIME) { ${ANIME_DETAIL} } }`,
    { id: Number(malId) },
  );
  if (!data.Media) throw new Error('Anime not found');
  return data.Media;
}

export async function hydrate(result: SearchResult, _key = ''): Promise<Partial<Title>> {
  if (result.source === 'jikan') {
    const m = await animeDetail(result.sourceId as number);
    return {
      sourceId: result.sourceId,
      source: 'jikan',
      totalEpisodes: m.episodes ?? null,
      statusText: prettyStatus(m.status),
      duration: m.duration ?? null,
      genres: m.genres?.length ? m.genres : result.genres,
      rating: m.averageScore ? Math.round(m.averageScore) / 10 : result.rating,
      year: m.seasonYear || m.startDate?.year || result.year,
      poster: m.coverImage?.extraLarge || m.coverImage?.large || result.poster,
      overview: stripHtml(m.description) || result.overview,
    };
  }

  if (result.source === 'tvmaze') {
    const [show, seasons] = await Promise.all([
      get<any>(`${TVMAZE}/shows/${result.sourceId}`),
      get<any[]>(`${TVMAZE}/shows/${result.sourceId}/seasons`),
    ]);
    const mapped = await mapTvmazeSeasons(result.sourceId, seasons);
    return {
      sourceId: result.sourceId,
      source: 'tvmaze',
      seasons: mapped,
      totalEpisodes: mapped.reduce((sum, season) => sum + season.episode_count, 0) || null,
      statusText: show.status,
      genres: show.genres || result.genres,
      poster: show.image?.original || show.image?.medium || result.poster,
      duration: show.averageRuntime || show.runtime || null,
      year: yearFrom(show.premiered) || result.year,
      overview: cleanSummary(show.summary) || result.overview,
    };
  }

  // Movies (Cinemeta). The meta call adds runtime and a full synopsis; failure is non-fatal.
  let meta: any = null;
  try {
    meta = (await get<any>(`${CINEMETA}/meta/movie/${result.sourceId}.json`, 12000, 1)).meta;
  } catch { meta = null; }
  const runtime = parseInt(String(meta?.runtime || ''), 10);
  return {
    sourceId: result.sourceId,
    source: 'cinemeta',
    totalEpisodes: null,
    genres: meta?.genres?.length ? meta.genres : result.genres,
    year: result.year || yearFrom(meta?.releaseInfo),
    rating: result.rating || Number(meta?.imdbRating) || null,
    poster: result.poster || meta?.poster || '',
    duration: Number.isFinite(runtime) ? runtime : null,
    statusText: 'Movie',
    overview: meta?.description || result.overview,
  };
}

export async function syncTitle(title: Title, _key = ''): Promise<Partial<Title>> {
  if (title.source === 'tvmaze' && title.kind === 'Series') {
    const [show, seasons] = await Promise.all([
      get<any>(`${TVMAZE}/shows/${title.sourceId}`),
      get<any[]>(`${TVMAZE}/shows/${title.sourceId}/seasons`),
    ]);
    const mapped = await mapTvmazeSeasons(title.sourceId, seasons);
    const old = title.seasons || [];
    const added = mapped.find((season) => !old.some((item) => item.season_number === season.season_number));
    const expanded = mapped.find((season) =>
      old.some((item) => item.season_number === season.season_number) &&
      season.episode_count > (old.find((item) => item.season_number === season.season_number)?.episode_count || 0),
    );
    return {
      seasons: mapped,
      totalEpisodes: mapped.reduce((sum, season) => sum + season.episode_count, 0) || title.totalEpisodes,
      statusText: show.status,
      overview: title.overview || cleanSummary(show.summary) || undefined,
      hasNewSeason: !!added || !!title.hasNewSeason,
      newSeasonNumber: added?.season_number ?? title.newSeasonNumber,
      newSeasonLabel: added ? `${added.name} Available` : expanded ? `${expanded.name} Updated` : title.newSeasonLabel,
      hasNewEpisodes: !!expanded || !!title.hasNewEpisodes,
      newEpisodesSeasonNumber: expanded?.season_number ?? title.newEpisodesSeasonNumber,
    };
  }

  if (title.source === 'jikan') {
    const m = await animeDetail(title.sourceId as number);
    const sequel = (m.relations?.edges || []).find(
      (edge: any) => edge.relationType === 'SEQUEL' && edge.node?.type === 'ANIME' && edge.node?.idMal,
    )?.node;
    const episodes = m.episodes ?? null;
    return {
      totalEpisodes: episodes,
      statusText: prettyStatus(m.status),
      overview: title.overview || stripHtml(m.description) || undefined,
      hasNewEpisodes: (episodes !== null && episodes > (title.totalEpisodes ?? 0)) || !!title.hasNewEpisodes,
      sequelAvailable: sequel && !title.sequelAvailable
        ? { mal_id: Number(sequel.idMal), title: sequel.title?.english || sequel.title?.romaji || 'Sequel' }
        : title.sequelAvailable,
    };
  }
  return {};
}
