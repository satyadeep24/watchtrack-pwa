import type { Title, WatchStatus } from './types';

export const now = () => Date.now();

export function totalFor(title: Title): number {
  return title.kind === 'Series'
    ? title.seasons?.find((season) => season.season_number === title.currentSeason)?.episode_count || 0
    : title.totalEpisodes || 0;
}

export function totalEpisodesFor(title: Title): number {
  return (title.seasons || []).reduce((count, season) => count + season.episode_count, 0) || title.totalEpisodes || 0;
}

export function watchedCount(title: Title): number {
  if (title.kind !== 'Series') return title.currentEpisode;
  if (title.watchStatus === 'Completed') return totalEpisodesFor(title);
  return (title.seasons || [])
    .filter((season) => season.season_number < title.currentSeason)
    .reduce((count, season) => count + season.episode_count, 0) + title.currentEpisode;
}

export function progress(title: Title): number {
  if (title.watchStatus === 'Completed') return 100;
  if (title.kind === 'Movie') return 0;
  if (title.kind === 'Series') {
    const seasons = title.seasons || [];
    const watchedBefore = seasons
      .filter((season) => season.season_number < title.currentSeason)
      .reduce((count, season) => count + season.episode_count, 0);
    const total = seasons.reduce((count, season) => count + season.episode_count, 0);
    return total ? Math.min(100, Math.round(((watchedBefore + title.currentEpisode) / total) * 100)) : 0;
  }
  return title.totalEpisodes
    ? Math.min(100, Math.round((title.currentEpisode / title.totalEpisodes) * 100))
    : 0;
}

export function markTitleCompleted(title: Title, rating = title.userRating): Title {
  const completedAt = title.completedAt || now();
  if (title.kind === 'Series') {
    const lastSeason = [...(title.seasons || [])].sort((a, b) => a.season_number - b.season_number).at(-1);
    return {
      ...title,
      watchStatus: 'Completed',
      currentSeason: lastSeason?.season_number ?? title.currentSeason,
      currentEpisode: lastSeason?.episode_count ?? title.currentEpisode,
      completedAt,
      updatedAt: now(),
      userRating: rating,
    };
  }
  if (title.kind === 'Anime') {
    return {
      ...title,
      watchStatus: 'Completed',
      currentEpisode: title.totalEpisodes ?? title.currentEpisode,
      completedAt,
      updatedAt: now(),
      userRating: rating,
    };
  }
  return { ...title, watchStatus: 'Completed', completedAt, updatedAt: now(), userRating: rating };
}

export function changeStatus(title: Title, status: WatchStatus): Title {
  if (status === 'Completed') return markTitleCompleted(title);
  return { ...title, watchStatus: status, completedAt: undefined, updatedAt: now() };
}

export function startTrackingUpdate(title: Title): Title {
  if (title.hasNewSeason) {
    const season = title.newSeasonNumber ?? Math.max(1, ...(title.seasons || []).map((item) => item.season_number));
    return {
      ...title,
      watchStatus: 'Watching',
      currentSeason: season,
      currentEpisode: 0,
      hasNewSeason: false,
      newSeasonNumber: undefined,
      hasNewEpisodes: false,
      newEpisodesSeasonNumber: undefined,
      updatedAt: now(),
    };
  }
  if (title.hasNewEpisodes) {
    return {
      ...title,
      watchStatus: 'Watching',
      currentSeason: title.newEpisodesSeasonNumber ?? title.currentSeason,
      currentEpisode: (title.newEpisodesSeasonNumber ?? title.currentSeason) === title.currentSeason ? title.currentEpisode : 0,
      hasNewEpisodes: false,
      newEpisodesSeasonNumber: undefined,
      updatedAt: now(),
    };
  }
  return { ...title, watchStatus: 'Watching', updatedAt: now() };
}
