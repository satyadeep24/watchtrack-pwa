export type Kind='Movie'|'Series'|'Anime';
export type WatchStatus='Watching'|'Plan'|'Completed'|'On Hold'|'Dropped';
export interface Season {season_number:number;episode_count:number;name:string;air_date?:string|null}
export interface Title {
 id:string; sourceId:number; kind:Kind; source:'tmdb'|'jikan'|'mock'; title:string; poster:string; year?:number|null; rating?:number|null; genres:string[]; statusText?:string; totalEpisodes?:number|null; duration?:number|null; seasons?:Season[]; currentSeason:number; currentEpisode:number; watchStatus:WatchStatus; userRating:number; note:string; addedAt:number; updatedAt:number; completedAt?:number; hasNewSeason?:boolean; newSeasonLabel?:string; newSeasonNumber?:number; newEpisodesSeasonNumber?:number; sequelAvailable?:{mal_id:number;title:string}; hasNewEpisodes?:boolean; isDemo?:boolean; runtime?:number;
}
export interface SearchResult {id:number;kind:Kind;source:'tmdb'|'jikan'|'mock';title:string;poster:string;year?:number|null;rating?:number|null;genres:string[];overview?:string;seasons?:Season[];totalEpisodes?:number|null;duration?:number|null;}
