import React, { Component, type ErrorInfo, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import PwaInstall from './PwaInstall';
import './style.css';

class AppErrorBoundary extends Component<{children:ReactNode},{hasError:boolean}> {
  state={hasError:false};
  static getDerivedStateFromError(){return {hasError:true};}
  componentDidCatch(error:Error,info:ErrorInfo){console.error('WatchTrack render error:',error,info);}
  render(){
    if(this.state.hasError)return <div style={{minHeight:'100vh',background:'#090a0e',color:'#fff',display:'grid',placeItems:'center',padding:24,textAlign:'center'}}>
      <div><h1 style={{fontSize:24,fontWeight:800}}>WatchTrack hit a snag</h1><p style={{color:'#a1a1aa',margin:'12px 0 20px'}}>Your saved watchlist is kept on this device. Reload the app to try again.</p><button onClick={()=>window.location.reload()} style={{background:'#ff7043',color:'#fff',borderRadius:12,padding:'12px 20px',fontWeight:700}}>Reload app</button></div>
    </div>;
    return this.props.children;
  }
}


if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register(`${import.meta.env.BASE_URL}sw.js`).catch((error) => {
      console.error('WatchTrack service worker registration failed:', error);
    });
  });
}

createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <AppErrorBoundary><App /><PwaInstall /></AppErrorBoundary>
  </React.StrictMode>,
);
