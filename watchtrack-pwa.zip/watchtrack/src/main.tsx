import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import PwaInstall from './PwaInstall';
import './style.css';

if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register(`${import.meta.env.BASE_URL}sw.js`).catch((error) => {
      console.error('WatchTrack service worker registration failed:', error);
    });
  });
}

createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <><App /><PwaInstall /></>
  </React.StrictMode>,
);
