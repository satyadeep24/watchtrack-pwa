import { useEffect, useState } from 'react';
import { Check, Plus, Star, X, LoaderCircle } from 'lucide-react';
import type { SearchResult, Title } from './types';
import { hydrate } from './api';

interface Props {
  r: SearchResult;
  added: boolean;
  onAdd: () => void;
  onClose: () => void;
}

export default function Preview({ r, added, onAdd, onClose }: Props) {
  const [extra, setExtra] = useState<Partial<Title>>({});
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let live = true;
    setLoading(true);
    hydrate(r)
      .then((value) => { if (live) setExtra(value); })
      .catch(() => { /* keep the data we already have from search */ })
      .finally(() => { if (live) setLoading(false); });
    return () => { live = false; };
  }, [r]);

  const poster = extra.poster || r.poster;
  const overview = extra.overview || r.overview || '';
  const year = extra.year || r.year;
  const rating = extra.rating || r.rating;
  const genres = (extra.genres?.length ? extra.genres : r.genres) || [];
  const seasons = extra.seasons?.length || r.seasons?.length;
  const episodes = extra.totalEpisodes ?? r.totalEpisodes;
  const minutes = extra.duration ?? r.duration;
  const status = extra.statusText || r.statusText;

  const facts: string[] = [];
  if (r.kind === 'Series' && seasons) facts.push(`${seasons} season${seasons > 1 ? 's' : ''}`);
  if (r.kind !== 'Movie' && episodes) facts.push(`${episodes} episodes`);
  if (minutes) facts.push(`${minutes} min${r.kind === 'Movie' ? '' : ' / ep'}`);
  if (status && status !== 'Movie') facts.push(status);

  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheet preview-sheet" onClick={(e) => e.stopPropagation()} role="dialog" aria-label={r.title}>
        <div className="preview-backdrop" style={poster ? { backgroundImage: `url("${poster}")` } : undefined} />
        <button className="preview-close" onClick={onClose} aria-label="Close"><X size={18} /></button>
        <div className="preview-head">
          <div className="preview-poster">
            {poster ? <img src={poster} alt="" /> : <div className="poster-fallback">{r.title.slice(0, 1)}</div>}
          </div>
          <div className="preview-meta">
            <span className="kind-label">{r.kind}{year ? ` · ${year}` : ''}</span>
            <h2>{r.title}</h2>
            {rating ? <span className="preview-rating"><Star size={13} fill="currentColor" /> {rating.toFixed(1)}</span> : null}
            {facts.length > 0 && <p className="preview-facts">{facts.join(' · ')}</p>}
          </div>
        </div>
        {genres.length > 0 && <div className="genre-pills">{genres.slice(0, 5).map((g) => <span key={g}>{g}</span>)}</div>}
        <div className="preview-body">
          {overview ? (
            <>
              <h3>Overview</h3>
              <p className={open ? 'preview-text' : 'preview-text clamp'}>{overview}</p>
              {overview.length > 180 && <button className="preview-more" onClick={() => setOpen(!open)}>{open ? 'Show less' : 'Read more'}</button>}
            </>
          ) : loading ? (
            <p className="subtle preview-loading"><LoaderCircle className="spin" size={14} /> Loading details…</p>
          ) : (
            <p className="subtle">No description available.</p>
          )}
        </div>
        <button className="primary-btn preview-add" disabled={added} onClick={onAdd}>
          {added ? <><Check size={16} /> Already in your list</> : <><Plus size={16} /> Add to my list</>}
        </button>
      </div>
    </div>
  );
}
