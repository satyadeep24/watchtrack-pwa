# WatchTrack discovery redesign — build notes

## Included in this update
- Reworked Discover into a poster-led discovery home with separate trending movie, popular series, and top-anime shelves.
- Anime discovery and search use Jikan directly and require no user key.
- Movie and TV discovery/search/details now use a shared TMDB proxy endpoint; the browser no longer asks users for a TMDB API key.
- Discovery results are cached locally for up to 24 hours and are used while offline.
- Existing `watchtrack_v1` localStorage library format and progress model are retained.
- Settings no longer asks each user for a TMDB key; export/import remains available.
- TypeScript pinned to 5.8.3 because the project uses `erasableSyntaxOnly`.

## Required before movie and TV catalogue is live
1. Deploy `backend/worker.js` as a Cloudflare Worker.
2. Add the TMDB key as a Worker secret named `TMDB_API_KEY`.
3. Set `ALLOWED_ORIGINS` to the exact deployed GitHub Pages origin.
4. Set `VITE_TMDB_PROXY_URL` at build time to `https://YOUR-WORKER.workers.dev/api/tmdb`.
5. Rebuild and redeploy GitHub Pages.

The Worker is a starter proxy. Add Cloudflare rate limiting and usage monitoring before public production use. Never put the TMDB key in frontend code or GitHub Pages files.

## Not included / still to implement
- Firebase Google sign-in and guest-to-Google migration. Guest storage remains device-local; the migration UI must not be considered active until Firebase config, Firestore rules, and a tested merge flow are added.
- Cloudflare Worker deployment and secret provisioning.
- A full production build could not be run in this environment because npm registry DNS access was unavailable. Existing domain tests pass (7/7). GitHub Actions must verify the build after upload.

## Data safety
The existing local library key `watchtrack_v1` and title structure are unchanged. Do not clear browser storage during deployment. Export a JSON backup before testing any migration.
