# WatchTrack no-key discovery build

## API architecture
- Movies: Cinemeta public metadata catalogue/search; no user API key.
- TV series: TVmaze search, show details and season metadata; no user API key.
- Anime: Jikan top/search/details; no user API key.
- Providers load independently so one provider failing does not block the other categories.
- Requests have timeouts and the discovery UI retains its local 24-hour cache.
- The TMDB proxy is no longer required by this frontend.

## Local data safety
- Existing `watchtrack_v1` localStorage library key is unchanged.
- Existing title IDs, statuses, season/episode progress, notes and ratings are retained.
- Existing TMDB-sourced titles remain in the library; this change does not delete or rewrite their saved progress. Legacy TMDB entries are not refreshed through the new public providers.
- Export a JSON backup before deployment/testing. Do not clear browser storage.

## Provider notes
- TVmaze attribution and share-alike terms must be respected.
- Cinemeta is a community Stremio metadata catalogue, not a guaranteed commercial API.
- Jikan has rate limits; avoid rapid repeat requests and use cached data.
- Provider metadata may differ; episode counts and poster availability are not guaranteed.

## Deployment
Replace the inner `watchtrack-pwa.zip` in the GitHub repository's outer ZIP with this updated archive, preserving the expected nested structure. The existing GitHub Actions workflow extracts the inner archive and runs `npm install` and `npm run build`.
