# WatchTrack source audit and dashboard refresh

## Changes

- Replaced the My List landing view with a compact premium tracking dashboard: library overview, active progress shelf, compact status tabs, and a clean collection list.
- Completed titles now normalize progress: series move to the final known season and episode; known-length anime move to their total episode count; movies receive a completion timestamp.
- Existing locally saved completed titles are normalized on load without changing their original `updatedAt` ordering.
- Returning a completed title to Watching, Plan, On Hold, or Dropped clears its previous completion timestamp.
- Starting a newly detected season starts at episode 0 in that season. Starting newly added episodes preserves existing progress when the same season was already being tracked.
- New season / new episode notifications persist across later syncs until the user starts tracking the update.
- Search providers now fail independently; a Jikan outage no longer discards successful TMDB results (and vice versa).
- TMDB API keys are URL-encoded, imported backups are validated, localStorage writes are guarded, and service-worker cache version is bumped to force refreshed assets.
- Monthly pace chart now uses actual completion counts from the last six months instead of placeholder bar heights.
- Dependencies are pinned to fixed versions rather than `latest`.

## Automated checks

Run with Node.js 22:

```bash
npm test
npm run build
```

Seven domain tests cover completion normalization, reopening a completed title, new-season progress reset, and preserving episode progress when new episodes arrive.

## Deployment note

The GitHub Pages workflow currently extracts `watchtrack-pwa.zip` and builds the project. Replace that archive with this updated archive, then run the existing `Deploy WatchTrack PWA` workflow. A successful Actions run verifies the production build and Pages deployment.
