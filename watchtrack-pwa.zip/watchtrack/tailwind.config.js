/** @type {import('tailwindcss').Config} */
export default { content:['./index.html','./src/**/*.{js,ts,jsx,tsx}'], theme:{extend:{colors:{ink:'#111115',surface:'#1C1C22',elevated:'#25252E',line:'#2C2C36',coral:'#FF7043',muted:'#A1A1AA',mint:'#34D399'},fontFamily:{sans:['Inter','sans-serif']}}},plugins:[] }
