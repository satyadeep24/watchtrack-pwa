import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Relative asset paths let this app work on GitHub Pages project URLs
// (https://<user>.github.io/<repo>/) as well as a custom domain.
export default defineConfig({
  plugins: [react()],
  base: './',
});
